# ai-course-materials
Contains FlexSim models and other files for a course on AI in Manufacturing taught at BYU

See the HelloWorld folder for getting started instructions.